def handler(event, context):
    return {"statusCode": 503, "body": "placeholder - awaiting first CI deploy"}
